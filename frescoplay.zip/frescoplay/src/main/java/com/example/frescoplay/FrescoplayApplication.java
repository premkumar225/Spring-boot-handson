package com.example.frescoplay;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.frescoplay.beans.Category;
import com.example.frescoplay.beans.Course;

@SpringBootApplication
public class FrescoplayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrescoplayApplication.class, args);
	}
	
	public static List<Category> getMainList() {
		
		List<Category> categories = new ArrayList<>();
		categories.add(new Category(1001, "Cloud Computing", "cloud computing description"));
		categories.add(new Category(1002, "Devops", "Devops description"));
		categories.add(new Category(1003, "Microservices", "Microservices Description"));
		return categories;
	}
	public static List<Course> getCourseList(){
		List<Course> courses = new ArrayList<>();
		courses.add(new Course(2001, 1001, "Azure Essentials", "11hrs", 100));
		courses.add(new Course(2002, 1001, "Cloud Computing", "8hrs", 100));
		courses.add(new Course(3001, 1002, "Git Slack Integration", "10hrs", 150));
		courses.add(new Course(3002, 1002, "More On Git", "11hrs", 100));
		courses.add(new Course(4001, 1003, "Caching Techniques", "13hrs", 100));
		courses.add(new Course(4002, 1003, "Redis", "9hrs", 100));
		return courses;
	}

}

