package com.example.frescoplay.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.frescoplay.FrescoplayApplication;
import com.example.frescoplay.beans.Category;
import com.example.frescoplay.beans.Course;

@RestController
public class DataController {

	@RequestMapping(value= "/category")
	public ResponseEntity<Object> getMainCourseList(){
		List<Category> mainList = FrescoplayApplication.getMainList();
		Map<Integer, Category> categoryRepo = new HashMap<>();
		for(Category category : mainList) {
			categoryRepo.put(category.getCategoryId(), category);
		}
		return new ResponseEntity<>(categoryRepo.values(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/category/{id}")
	public ResponseEntity<Object> getCourseList(@PathVariable("id") String id){
		List<Course> courseList = FrescoplayApplication.getCourseList();
		Map<Integer, Course> courseListRepo = new HashMap<>();
		for(Course course : courseList) {
			if(Integer.parseInt(id)==course.getCategoryId())
				courseListRepo.put(course.getCourseId(),course);
		}
		return new ResponseEntity<>(courseListRepo.values(), HttpStatus.OK);
	}
}
