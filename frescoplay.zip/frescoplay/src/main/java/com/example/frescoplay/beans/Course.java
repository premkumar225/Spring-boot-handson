package com.example.frescoplay.beans;

public class Course {

	private int courseId;
	
	private int categoryId;
	
	private String name;
	
	private String duration;
	
	private int miles;

	public Course(int courseId, int categoryId, String name, String duration, int miles) {
		super();
		this.courseId = courseId;
		this.categoryId = categoryId;
		this.name = name;
		this.duration = duration;
		this.miles = miles;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getMiles() {
		return miles;
	}

	public void setMiles(int miles) {
		this.miles = miles;
	}
	
	
}
